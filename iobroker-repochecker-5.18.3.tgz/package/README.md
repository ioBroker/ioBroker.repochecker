# Adapter repository checker

This is a code for frontend and back-end of the service <https://adapter-check.iobroker.in/>

If you want to add your adapter to the public ioBroker repository, all tests on this page must be OK.

## How to test via cli

When running the repository checker via the command line, you **need** to add the repository as parameter, while the branch parameter (`master/main/dev`) is optional. If this parameter is omitted, the `default` branch (typically master / main) will be checked.

```
npx @iobroker/repochecker <repo> [branch]`
```

For extra debugging outputs you can pass the `--debug` parameter.

For a local test you can pass the `--local` parameter. Most of the files are read locally.
The link to the GitHub repository is still necessary because data from the project settings on GitHub is also checked.

Example:

`npx @iobroker/repochecker https://github.com/ioBroker/ioBroker.repochecker --local`

<!--
	Placeholder for the next version (at the beginning of the line):
	### **WORK IN PROGRESS**
-->
### 5.18.3 (2026-06-06)

-  (mcm1957) Support for objectStructure check added

### 5.17.9 (2026-06-04)

-  (mcm1957) Require release-script 5.2.1.
-  (mcm1957) Searching for release tag workflow has been fixed.

### 5.17.6 (2026-06-03)

-  (mcm1957) Severities have been adapted.

### 5.17.5 (2026-06-02)

-  (mcm1957) Minor checkings at README formatting have been done.

### 5.17.4 (2026-05-31)

-  (mcm1957) default value for engines corrected.

### 5.17.3 (2026-05-30)

- (mcm1957) exclude 'scripts' directory from scanning

### 5.17.2 (2026-05-30)

- (mcm1957) False positive when searching copyright line at README.md fixed.

### 5.17.1 (2026-05-30)

- (mcm1957) Disable [E6031] Changelog section in README.md is missing entry/entries.

### 5.17.0 (2026-05-30)

- (mcm1957) jsonConfig component oauth2 added.
- (mcm1957) Some translation issue are compacted better.
- (mcm1957) handle package alias definitiosn from tsconfig.json
- (@copilot) Improved `[E5004]`/`[W5004]`/`[W5005]` checks: `setInterval()`/`setTimeout()` are now scanned across all source files (not just the main file); bare calls (not prefixed with `this.` or `adapter.`) are flagged with a suggestion to use `this.setInterval()`/`adapter.setInterval()` or `this.setTimeout()`/`adapter.setTimeout()` instead. Messages also note when no matching `clearInterval()`/`clearTimeout()` is detected in the file.
- (@copilot) Added support for `// @repochecker: optional dependency 'pkg'` comments in source files: missing dependency warnings (`[W5042]`) are suppressed for declared optional packages, and dedicated warning/suggestion messages are emitted for invalid/unused/optional-missing declarations.
- (@copilot) Adjusted timer checks: bare `setInterval()`/`setTimeout()` calls are now reported once as suggestions (`[S5004]`/`[S5005]`) across all source files, while missing matching `clearInterval()`/`clearTimeout()` calls are reported separately as warnings (`[W5004]`/`[W5005]`).
- (@copilot) Updated adminUI/file consistency checks: `admin/jsonConfig.json(5)` now consistently warns (`[W5046]`) when `common.adminUI.config !== "json"`, and added the same warning pattern for `admin/jsonTab.json(5)` via `[W5064]` when `common.adminUI.tab !== "json"`.

### 5.16.1 (2026-05-28)

- (mcm1957) Processing of require / import filenames has been adapted.

### 5.16.0 (2026-05-28)

- (mcm1957) Incorrect checking of provenence / trusted publishing has been fixed.
- (mcm1957) Checking of @tsconfig/nodeNN has been added
- (mcm1957) Checing of state roles has been renewed
- (mcm1957) Component qrCodeSendTo has been added

### 5.15.1 (2026-05-27)

- (mcm1957) X56xx issues have been count-limited

### 5.15.0 (2026-05-27)

- (mcm1957) I18n checks have been extended

### 5.14.2 (2026-05-27)

- (mcm1957) Crash when checking github dependencies has been fixed

### 5.14.1 (2026-05-26)

- (mcm1957) support for exceptions for some package update suggestions added

### 5.14.0 (2026-05-26)

- (@copilot) Added `[E1143]`: when `package.json` `main` points to a `.ts` file, `io-package.json` must set `common.compact` to `false`. In this case `[S1039]` is no longer emitted.
- (@copilot) Added `[W5060]`: warns when a package is listed in `dependencies` of `package.json` but is not imported or required by any scanned source file. Plugin packages implied by `io-package.json common.plugins` are ignored to avoid false positives.
- (@copilot) Added `[S3042]`/`[S3043]`/`[S3044]`: suggest using only the major version tag (e.g. `@v2`) when `test-and-release.yml` pins a specific minor/patch version (e.g. `@v2.0.0`) for `ioBroker/testing-action-check`, `ioBroker/testing-action-adapter`, or `ioBroker/testing-action-deploy`.
- (@copilot) Added notification scope checks in `io-package.json`: errors when `notifications[].scope` is missing and warns when the scope is neither the adapter name nor in a general allowlist (currently empty).
- (@copilot) Moved file-list-based eslint config file checks to run after code file discovery and now abort on missing internal `context.filesList`.
- (@copilot) Added eslint migration/config checks for package/workflow validation, including `lint: true` verification in `test-and-release.yml`.
- (@copilot) Improved `test-and-release.yml` OS checks to evaluate matrix or action-step OS coverage against `package.json` `os` restrictions, including alias mapping (`linux`/`win32`/`darwin`).
- (@copilot) Added `[W5059]`: warns when adapters using class mode (`class ... extends utils.Adapter`) still call `utils.adapter(...)` in source files.

### 5.13.2 (2026-05-26)

- (mcm1957) Adapter some severities for new adapters.
- (mcm1957) Missing state common attributes added.

### 5.13.1 (2026-05-24)

- (mcm1957) Some flase positives have been fixed.

### 5.13.0 (2026-05-22)

- (@copilot) Ignored `/www`, `/template`, and `/templates` during source dependency scanning, ignored `native.webInstance` for extension adapters in native checks, and updated `[W1130]` array default validation to require a JSON-stringified array. Related to [#881].
- (@copilot) Fixed `[W8905]` dependabot coverage logic to accept matching npm `directory`/`directories` entries (including wildcard patterns) for each non-root `package.json`.
- (@copilot) Added an error for `common.nondeletable=true` in `io-package.json`, with a prepared (currently empty) allowlist for adapters that are allowed to use this reserved flag.
- (@copilot) Fixed `[W0069]` scope: now checks only packages reachable from `dependencies` in `package.json` (including their transitive sub-dependencies), while ignoring packages that are only brought in by `devDependencies` or `optionalDependencies`.
- (@copilot) Stopped source-code checks from scanning files in `doc/` and `docs/` directories, preventing false positives like `[E5049]` from documentation helper files [#874].
- (@copilot) Added `[W0069]`/`[S0070]`: checks that all dependencies in `package-lock.json` require a Node.js version compatible with the adapter's `engines.node` minimum. If `package-lock.json` is absent, attempts to create it via `npm install --package-lock-only`. Reports `[W0069]` for incompatible packages and `[S0070]` when the check cannot be performed. Related to #310
- (@copilot) Extended `instanceObjects` validation for `io-package.json`: now checks `_id`, valid object/state types, state `common.*` structure/types, and role compatibility against official ioBroker state-role definitions, reporting findings as warnings.
- (@copilot) Added `[W5516]`: warns when the `default` value in a jsonConfig component definition has a JavaScript type that does not match the expected type for that component (e.g. a `number` component with a string default like `"5"`, or a `checkbox` with a numeric default). Related to [#857].
- (@mcm1957) Added `[E6025]`: `README.md` now raises an error when it does not contain exactly one H1 (`#`) heading. Related to #176.
- (@copilot) Added `[W5053]`: warns when `admin/jsonCustom.json(5)` exists but custom support is not declared in io-package.json. Related to [#760].
- (@copilot) Added `[W5054]`: warns when `admin/blockly.js` exists but blockly support is not declared in io-package.json (`common.blockly` not set). Related to [#760].
- (@copilot) Added `[W5055]`: warns when `admin/index.html` exists but materialize UI is used (the file is for admin2 and is outdated). Related to [#760].
- (@copilot) Added `[W5056]`: warns when `admin/custom.html` or `admin/custom_m.html` exists — these HTML-based custom dialogs are no longer supported; migrate to `admin/jsonCustom.json`. Related to [#760].
- (@copilot) Added `[W6023]`/`[W6024]` README checks for adapters using the Sentry plugin: warn when the required Sentry notice is missing and when it appears too far down in the document.
- (@copilot) Added `[W5052]`: warns for adapter-core `setObject()` usage (`this.setObject(...)` / `adapter.setObject(...)`) and suggests using `setObjectNotExists()` or `extendObject()` instead. Detection ignores comments and string literals to avoid false positives.
- (@copilot) Added `[E9508]` and extended `.npmignore` packaging checks so `CHANGELOG_OLD.md` is not shipped in npm packages.
- (@copilot) Added `[E9509]`/`[E9510]`: error when `.dev-server` directory is present in repository but not excluded from npm packaging (via `package.json "files"` or `.npmignore`). Related to #875.
- (@copilot) Added `[W5052]`/`[W5053]`: when jsonConfig is used, password fields found in `admin/*.json` and `admin/*.json5` (outside table components) are now checked against `protectedNative` and `encryptedNative` in `io-package.json`.

### 5.12.1 (2026-05-20)
- (mcm197) cleanup some duplicate numbers

### 5.12.0 (2026-05-20)

- (@copilot) Added `[S6022]`: suggest adding a link to `CHANGELOG_OLD.md` in `README.md` when the file exists but no reference to it is found in the readme.
- (@copilot) Extended `@types/node` version checks (`W0066`, `S0067`, `E0068`) to cover all dependency types (`dependencies`, `devDependencies`, `optionalDependencies`), not just `devDependencies`. Defaults to Node.js 20 when no `engines` clause is present. Fixed `context.error.push` typo bug and `0;` no-op in `S0065` check. Related to #855.
- (@copilot) Added workflow run tagging checks in `M3000_Testing.js`: validates latest `test-and-release.yml` run status, verifies GitHub tags for current/package and npm (`latest` and newest) releases, and checks tag-triggered workflow run outcomes with clickable run links.
- (@copilot) Extended testing workflow checks to use configurable required action versions (`ioBroker/testing-action-check`, `ioBroker/testing-action-adapter`, `ioBroker/testing-action-deploy`) and warn when lower action versions are used.
- (@copilot) Split non-matrix node.js minimum/recommended thresholds into dedicated values for `check-and-lint` and `deploy` workflow jobs.
- (@copilot) Changed deploy trusted-publishing permission check from warning `W3018` to suggestion `S3018`.
- (@copilot) Added node.js version checks for `check-and-lint` (E3020, S3021) and `deploy` (E3022, S3023) jobs in `test-and-release.yml`, raising an error if below minimum and a suggestion if below recommended version. Minimum/recommended values are adjusted upward if the adapter's `engines:node` clause requires a higher version.
- (@copilot) Added checks for `adapter-tests` matrix: warns (W3024) about non-recommended node versions, errors (E3025) when required node versions are missing, warns (W3026) when recommended node versions are absent, and warns (W3027) when OS entries (`ubuntu-latest`, `windows-latest`, `macos-latest`) are missing from the matrix.
- (@copilot) Added `testingNodeJs` constants to `lib/config.js` for configuring node.js version requirements and OS requirements for `test-and-release.yml` checks.
- (@copilot) Added `[W1116]`: warn when the sentry plugin is configured in `common.plugins` of io-package.json but `@sentry/*` packages are listed as `dependencies` in package.json (explicit sentry dependencies are not needed when using the sentry plugin).
- (@copilot) Added `[S5051]`: suggest using `this.delay()` instead of custom `sleep`/`wait` function implementations found in adapter source files.
- (@mcm1957) Require node.js 20 and recommedn node.js 22 now
- (@copilot) Fixed `GLOBAL ERROR: TypeError: Cannot read properties of undefined (reading 'includes')` in `checkCode` when running in local mode (`--local`).
- (@copilot) CLI now exits with code `1` when errors are found, enabling use in command chains like `npx @iobroker/repochecker repo --local && npm run release`.
- (@copilot) Added `[W8918]`: warn when any workflow in `.github/workflows/` references an action from `iobroker`, `iobroker-community-adapters`, or `iobroker-bot-orga` without a versioned tag (e.g. `@main` or `@master`). [#851]
- (@copilot) Added `[S0065]`/`[W0066]`/`[S0067]`: check `@types/node` devDependency against the minimum Node.js version from the `engines` clause in package.json. Suggests adding it if missing, warns if it allows a higher major version, and suggests updating if it only covers lower versions.
- (@copilot) Fixed `[W0066]` `@types/node` semver check to correctly detect ranges that allow any higher major version (e.g. `^24.10.1` with min Node.js 20 now raises the warning as expected).
- (@copilot) Added [E5049]/[W5049]: scan source files for `process.env` usage. Reports an error when `common.compact` is `true` or not defined (compact mode incompatible), and a warning when `common.compact` is explicitly `false`.
- (@copilot) Added [E5050]/[W5050]: scan source files for `process.exit()` calls. Reports an error when `common.compact` is `true` or not defined (incompatible with compact mode), and a warning when `common.compact` is explicitly `false`.
- (@copilot) Warn when dependabot npm root entries do not ignore major or minor @types/node updates.
- (@copilot) Added `[W6021]`: warn when `## License` is not the last section in README.md.
- (@copilot) Added `[W1115]`: warn when a plugin listed in `common.plugins` of io-package.json is missing its corresponding `@iobroker/plugin-<name>` dependency in package.json.

### 5.11.1 (2026-04-25)

- (@ticaki) Local mode has been fixed.

### 5.11.0 (2026-04-21)

- (@copilot) Added `[W2007]`: warn when the npm `latest` dist-tag points to an alpha/pre-release version, as such releases will be ignored by repository updates.
- (@copilot) Added `lib/postprocessing.js` module: new adapters (where `isNewAdapter` is set) now have selected warnings and suggestions promoted to errors or warnings according to a configurable severity-remap table, making the checker stricter for new adapter submissions.
- (@copilot) Fixed adapter detection to ensure the `isNewAdapter` flag is set before configuration logging. Added a new `getLatestRepo` preprocessing step so that the flag is correctly visible in the environment log output.
- (@copilot) Added German translation of OBJECTDUMP.md as OBJECTDUMP_de.md.

### 5.10.4 (2026-04-12)

- (@copilot) Enhanced E6013 check: detects additional discouraged installation methods in README.md, including `iobroker`/`iob` npm install and url commands, and `npm install`/`npm i` with `owner/iobroker.adaptername` GitHub shorthand. Updated error message to mention "directly from GitHub, directly from npm or using npm commands".

### 5.10.3 (2026-04-11)

- (@copilot) Fixed false positive W5042 for TypeScript type-only imports: `import type { Foo } from 'pkg'` no longer registers `pkg` as a required runtime dependency. Related to [#833]

### 5.10.2 (2026-04-11)

- (@copilot) Fixed false positive `[E9507]` for i18n directories inside source directories (`src-rules`, `rules-src`, `src-editor`, `src-widgets`, `admin/src`, etc.) by expanding the ignored source directory list and checking the full parent path instead of only the top-level segment. Related to [#828].
- (@copilot) Added adapter-specific exceptions to E0050 blacklist: `@iobroker/plugin-sentry` is now allowed as a dependency for `ioBroker.javascript`.
- (@copilot) Added system-provided packages ignore list for W5042: `@iobroker/plugin-sentry` will no longer raise "dependency might be missing" warnings as it is provided by js-controller.

### 5.10.1 (2026-04-10)

- (@copilot) Fixed `TypeError: minimatch is not a function` in `checkNpmIgnore` by correctly destructuring `minimatch` from the `minimatch` v10+ package export.
- (@copilot) Added `minimatch` as an explicit dependency in `package.json` (used by `M9000_GitNpmIgnore.js` for glob pattern matching).
- (@copilot) Fixed false positives in `[E9507]` when i18n directories are covered by glob patterns in `package.json` `"files"` field.
- (@copilot) Added [W4047]: warn when adapter is found in the latest repository but not yet available in the stable repository. Related to [#820].
- (@copilot) Added `[E9506]`: error when an i18n directory is explicitly excluded by `.npmignore`, which would cause translations to be missing from the npm package.
- (@copilot) Added `[E9507]`: error when an i18n directory is present in the repository but not covered by the `"files"` field in `package.json`, which would cause translations to be missing from the npm package.

### 5.9.1 (2026-04-08)

- (@copilot) Added `isNewAdapter` flag: set to `true` when adapter is not listed in the latest repository, with an info log when set.
- (@copilot) Added `--strict` command line option: when active, outputs an info log "running in strict mode".
- (@copilot) `[S6020]` suggestion to add `CHANGELOG_OLD.md` is now only shown when `isNewAdapter` is set or strict mode is active.

### 5.9.0 (2026-04-08)

- (@copilot) Added checks W1114/S1114: warn when `common.schedule` is set to a non-empty value for daemon adapters (not supported), and suggest removal when `common.schedule` is an empty string for daemon adapters (unused). Related to [#806].
- (@copilot) Added checks to help maintain organized changelog files: warns when CHANGELOG.md is present (changelog belongs in README.md), when both CHANGELOG.md and CHANGELOG_OLD.md coexist, when the README changelog exceeds 20 entries without a CHANGELOG_OLD.md, and suggests adding CHANGELOG_OLD.md when no such file exists. [W6017, W6018, W6019, S6020]

### 5.8.0 (2026-04-07)

- (@copilot) Limit the listing of `allowedValues` in schema validation errors (E1105, W5512) to 5 values, appending `...` when there are more possibilities.
- (@copilot) [W5046] Added warning when `admin/jsonConfig.json` or `admin/jsonConfig.json5` is present but `common.adminUI.config` is not set to `"json"` in `io-package.json`.
- (@copilot) [W5047] Added warning listing obsolete files (`admin/index.html`, `admin/index_m.html`, `admin/style.css`) when jsonConfig is used.

### 5.7.1 (2026-04-07)

- (mcm1957) Improve jsonConfig schema validation messages.

### 5.7.0 (2026-04-06)

- (@copilot) [S8913] automerge suggestion is no longer shown when dependabot is not configured ([S8901]).
- (@copilot) Language detection: `GERMAN_WORDS` and `ENGLISH_WORDS` arrays sorted alphabetically; chapters titled "Haftungsausschluss" in README.md are now ignored when checking for German text.
- (@copilot) Added [W8915]: warn when a dependabot npm entry has no cooldown or a cooldown of less than 5 days configured, recommending at least 7 days to reduce supply chain risk.
- (@copilot) Added JSON5 support for `jsonTab.json5`: `admin/jsonTab.json` and `admin/jsonTab.json5` are now read and parsed; E5044 is raised for parse errors and E5045 when the file is missing but tab support is declared. [#780]
- (@copilot) Fixed false-positive W4042/W4044 warnings for adapters using only `jsonConfig.json5`: the VS Code schema checks now detect which config files actually exist in the repository and use `some()` instead of `every()` to match schema entries, preventing false warnings when a valid json5-only schema is configured. [#780]
- (@copilot) Added schema validation for all present jsonConfig files (`admin/jsonConfig.json`, `admin/jsonCustom.json`, `admin/jsonTab.json` and their `.json5` variants) against the official jsonConfig JSON schema; errors reported as E5512, schema download failures as W5513, and exceptions as E5514. [#803]

### 5.6.9 (2026-04-02)

- (mcm1957) Ignore "widgets" directory when scanning for imported packages.

### 5.6.7 (2026-04-02)

- (@copilot) Fixed false positive package detection in `extractImports`: dynamic imports like `import("pkg")` no longer incorrectly trigger the `import ... from ...` pattern, preventing values in log strings (e.g. `from 'force_full'`) from being mistaken for package names.

### 5.6.6 (2026-03-29)

- (mcm1957) Severity for [S3010] has been corrected.

### 5.6.5 (2026-03-27)

- (@copilot) Exclude `gulpfile.js` and `lib/tools.js` from W5042/S5043 dependency scanning; added easy-to-extend `excludedSourceFiles` and `excludedSourceRelPaths` Sets for future exclusions.

### 5.6.2 (2026-03-27)

- (@copilot) Suppress unwanted npm E404 error output when checking adapters that are not published on npm.
- (@copilot) Added E2006 error when an npm package has no published versions available, instead of silently skipping version checks.
- (@copilot) Handle unpublished npm packages: detect "Unpublished on ..." response from npm registry and report a specific E2000 error instead of the generic "not found" message; suppress raw npm error logs for unpublished packages in README/LICENSE year checks. [#766]
- (@copilot) Fixed crash in checkNpm (E2000-E2999) when npm package has no `dist-tags` or `versions` field in registry response. [#764].
- (@copilot) Added W5042 and S5043 checks: source files (`*.js`, `*.mjs`, `*.cjs`, `*.ts`) are now scanned for `require`/`import` statements (excluding `admin/`, `doc/`, `src-admin/`, `test/` directories and `*.test.*`/`*.config.*` files). W5042 warns when an imported package is not listed in `dependencies` of `package.json`. S5043 suggests using the `node:` prefix when importing known Node.js built-in modules without it.

### 5.5.5 (2026-03-24)

- (mcm1957) remove '[S6014] README.md section "## Installation" should be removed unless the adapter requires special installation handling.'

### 5.5.4 (2026-03-22)

- (@copilot) Fixed E6015/W6016 false positives: German (and English) language detection now ignores fenced code blocks, inline code, blockquote lines, link URLs, and image markup before analyzing the README text.

### 5.5.3 (2026-03-19)

- (@copilot) Fixed E3016 false positive: transitive `needs` dependencies are now considered, so `deploy` depending on `adapter-tests` which already depends on `check-and-lint` is correctly accepted. Related to [#756].
- (@copilot) W5041 warning now includes the list of languages that contain the example keys (e.g. `languages: en, de, ru`).

### 5.5.2 (2026-03-17)

- (@copilot) E5040 and W5041 messages now include the specific detected key(s) (e.g. `option1`, `option2`, or both) instead of the generic `option1/option2` placeholder. Only one issue is raised even when multiple keys are detected.
- (@copilot) Fixed E1111/W1111 checks: E1111 and W1111 are now renamed to E5040 and W5041 (correct numbering range for M5000_Code module). Both checks now correctly exempt adapters where `option1`/`option2` keys are genuinely used in `admin/index.html`, `admin/index_m.html`, or as keys in `admin/jsonConfig.json`/`admin/jsonConfig.json5`. Related to [#746].

### 5.5.1 (2026-03-17)

- (@copilot) Added W5039 check: warns when `admin/words.js` exists but is not referenced anywhere in the codebase for adapters using jsonConfig. The file seems to be outdated and should be removed [#745].
- (@copilot) Added W3018 and W3019 checks: when deploy job uses `ioBroker/testing-action-deploy@v1`, warns if job-level permissions (`contents: write`, `id-token: write`) are missing (W3018) or if the `npm-token` parameter is specified (W3019), as trusted publishing will not work in either case. Related to [#742].
- (@copilot) Added W1113 check: warns when `native` config object contains properties but `common.adminUI.config` is set to `"none"`, as the native config will not be used without an admin UI config.
- (@copilot) Added E1112 check: error when `notifications` in `io-package.json` are not translated into all supported languages (en, de, ru, pt, nl, fr, it, es, pl, uk, zh-cn) [#734].
- (@copilot) Fixed E3016 false positive: no longer requires `deploy` job to declare `needs` for `check-and-lint`/`adapter-tests` when those jobs do not exist in the workflow (e.g. `onlyWWW` adapters). Related to [#733].
- (@copilot) Added E6015 check: error when README.md contains German language words. Added W6016 check: warning when README.md does not appear to be written in English.
- (@copilot) Multiple S8906 suggestions for dependabot entries using `schedule: interval: monthly` are now combined into a single suggestion. [#696]
- (@copilot) Added W1111 check: warns when example configuration keys `option1`/`option2` are found in `io-package.json` native section or i18n translation files. Only one warning is issued even if both locations contain example config.
- (@copilot) Added E6012 check: error when README.md contains direct npm install instructions (`npm install iobroker.*`, `npm i iobroker.*`, `cd /opt/iobroker`). Related to [#722].
- (@copilot) Added E6013 check: error when README.md instructs users to install from GitHub using `iobroker url`. Related to [#722].
- (@copilot) Added S6014 suggestion: when README.md contains an `## Installation` section. Related to [#722].
- (@copilot) Extended E6013 check: now also triggers on "Install the adapter via ioBroker Admin as a ZIP file" and "Install from own URL" phrases (case-insensitive). Related to [#727].

### 5.4.1 (2026-03-13)

- (mcm197) E3008 has been fixed

### 5.4.0 (2026-03-11)

- (@copilot) OnlyWWW adapters no longer require testing dependencies or adapter test workflows (skips E3000, E3011, and W3015 checks for adapters with `common.onlyWWW = true`).

### 5.3.0 (2026-03-11)

- (@copilot) Added validation for dependabot configuration: checks for required ecosystems (github-actions, npm), schedule settings, open-pull-requests-limit, and automerge workflow configuration (checks S8901–S8914).
- (@copilot) Extended W5034 check to also warn when `.ts` and `.js`/`.cjs`/`.mjs` versions of the same file exist in the same directory.
- (@copilot) E3003 YAML parse error for workflow files now logs only the first line (without the file excerpt).
- (@copilot) Added DEPENDABOT issue template for GitHub Copilot tasks.
- (@copilot) Extended testing checks (M3000_Testing.js): added checks for testing devDependency, test-and-release.yml workflow file presence, validity and required configuration.

### 5.2.3 (2026-02-26)

- (@copilot) Fixed crash when `devDependencies` is missing from package.json. [#675]

### 5.2.2 (2026-02-25)

- (mcm1957) Add warning if fa-icon entry still exists.
- (@copilot) Added W6011/W7004 checks: warn when copyright lines in README.md or LICENSE are separated by an empty line instead of trailing two spaces.
- (@copilot) Fixed false positive W6009/W7003: warning for non-consecutive copyright lines (separated by other text or empty lines) is no longer issued. [#672]
- (@copilot) Fixed false positive S0048/S0047 for npm alias dependencies (e.g. `"npm:real-package@^1.2.3"`). [#667]
- (@copilot) Added jsonConfig components `iframe` and `iframeSendTo` with minAdmin 7.7.28.
- (@copilot) Added jsonConfig component `yamlEditor` with minAdmin 7.7.31. [#660]
- (@copilot) Restructured `validComponents` entries in M5500\_\_JsonConfig.js to objects with `function` and `minAdmin` properties.
- (@copilot) Added `checkDocker` and `infoBox` as known jsonConfig components to fix false-positive E5504 errors; set minAdmin 7.7.31 for `checkDocker`. [#663]
- (mcm1957) require js-controlelr 6 and admin 7 now. [#641] [#589]
- (mcm1957) required and suggested releases of standard packages have been updated.
- (mcm1957) Dependencies to packages named 'admin' and 'iobroker' have been disallowed. [#617]

### 5.1.1 (2025-12-01)

- (@copilot) Updated repository URLs from http://repo.iobroker.live to https://download.iobroker.net

### 5.1.0 (2025-11-25)

- (@copilot) Added check for conflicting JSON/JSON5 files with same base name in same directory (E5038) [#169]
- (@copilot) Added .releaseconfig.json verification to check plugins listed match installed devDependencies (E5036, W5037)
- (@copilot) Added YAML file validation check (E5035) to verify .yml and .yaml files are well-structured [#618]
- (@copilot) Added flexible conditional dependency requirements support [#609]
- (mcm1957) add warning if iobroker bot PRs are open. [#596]
- (mcm1957) remove S1094, protectedNative elements need not be encrypted. [#579]
- (mcm1957) required and suggested releases of standard pacakges have been updated.
- (mcm1957) Log errors at io-package validation as errors now.
- (mcm1957) Text for E1000 has been corrected. [#576]
- (mcm1957) Pathc information has been added to error E5509. [#394]

### 5.0.2 (2025-10-03)

- (mcm1957) Some debug log has been removed.

### 5.0.1 (2025-10-03)

- (mcm1957) A crash at adapters which do not contain news entry at io-package.json has been fixed. [#572]

### 5.0.0 (2025-10-02)

- (mcm1957) Suppress W6010 if adapter not yet published at npm. [#567]
- (@copilot) Added check for deprecated common.jsonConfig property - warns if adminUI exists (W1109), errors if adminUI missing (E1109)
- (@copilot) Added check (W0063) for unneeded devDependencies when @iobroker/testing >= 5.1.1 is installed
- (@copilot) Added check for conflicting JavaScript file extensions (.js, .cjs, .mjs) in the same directory (E5034)
- (@copilot) Improved copyright year check to find all years in multiple copyright entries and use the newest one
- (@copilot) Added check for missing trailing spaces in multiple copyright lines (W6009, W7003)
- (mcm1957) Strict mode requirements have been loosend at schema validation.
- (mcm1957) Do not log missing jsonConfig schema at vscode is no jsonConfig is used. [#548]
- (mcm1957) News entry at io-package.json is no longer required for alpha release. [#532]
- (mcm1957) Report missing README changelog for alpha releases as suggestion only. [#533]
- (mcm1957) Release of @iobroker/testing has been updated to 5.1.1.
- (mcm1957) Text for dependency update suggestion has been changed to make more clear that this should be really done. [#515]
- (mcm1957) Suggestion to migrate to jsonConfig has been changed to suggest jsonConfig or react based UI. [#524]
- (mcm1957) Alpha release are no longer reported as missing at npm / latest. [#425]
- (mcm1957) Suggestions to avoid fixed dependencies has been compressed to a maximum of one suggestion even if multiple ffixed dependencies exist [#512].
- (mcm1957) E4033 is always an error [#541].
- (mcm1957) Empty adaptername in finding has been fixed [#549].
- (mcm1957) Text for 9006 has been changed (.commitinfo hint) [#542].
- (@copilot) Renumbered all error, warning and suggestion codes from 3-digit to 4-digit format according to new numbering system
- (@copilot) Added version format validation check (E061) for invalid semver format according to ioBroker requirements
- (@copilot) Added structured GitHub issue templates for bug reports, false positives, new checks, check changes, and enhancements
- (@copilot) Fixed deprecated function checking for adapter methods called outside class context

### 4.2.0 (2025-09-20)

- (mcm1957) 'Request' replacement text changed to suggest 'node:fetch' [#498].
- (@copilot) Fixed false positive W533 warnings for deprecated adapter methods when called on local functions with same names [#520].
- (mcm1957) '[W438] .vscode/settings.json file missing "json.schemas" property' has been converted to suggestion [#516].
- (mcm1957) Severity of '[S191] admin dependency...' has been corrected [#510].
- (copilot) Added io-package.json schema validation against official schema (W205, W207, W208) [#503].
- (copilot) Added check for deprecated adapter methods (createState/createChannel/createDevice/deleteState/deleteChannel/deleteDevice) (W533) [#182].
- (copilot) Added check for outdated lib/tools.js file usage (W532) [#432].
- (copilot) Added VS Code schema definitions checker for .vscode/settings.json - validates json.schemas for io-package.json and jsonConfig files [#336].
- (copilot) Change W510 to E510: Convert missing admin i18n files from warning to error [#400].
- (copilot) Renumbered all issues in M500\_\_JsonConfig.js from 500-511 range to 550-561 range [#481].
- (copilot) Added check for .commitinfo file - error if present (E905), warning if not in .gitignore (W906) [#467].
- (copilot) Added check for allowInit attribute [#181].
- (copilot) Added detection for empty dependency objects in io-package.json (E200, E201) [#422].
- (copilot) Added suggestion to restart 'vis-2' when 'vis' is in restartAdapters (S202) [#412].
- (copilot) Modified W513 gulpfile.js warning to check for @iobroker/adapter-dev dependency and add S531 suggestion [#469].
- (copilot) Fixed W195 warning for array elements - add W203 warning for unsupported array encryption [#399].

### 4.1.0 (2025-09-11)

- (mcm1957) eslint-config and testing suggestions have been updated.
- (mcm1957) adapter-core suggestions has been updated.
- (mcm1957) URGENT and IMPORTANT issued are watched now.
- (mcm1957) Using @iobroker/eslint-config is suggested now.
- (mcm1957) Adding @iobroker/testing to dependencies is logged as error now [#447].
- (mcm1957) Text for S191 has been extended [#393].
- (mcm1957) Text for S052 has been corrected [#434].
- (mcm1957) Formatting if W174 has been improved [#408].
- (mcm1957) @types/\* as dependency now raise a warning [#421].
- (mcm1957) Dependencies have been updated.

### 4.0.2 (2025-08-12)

- (mcm1957) js-controller 6.0.11 recommended now.

### 4.0.1 (2025-08-11)

- (mcm1957) Wrong suggestion to add admin dependency has been corrected [#452].
- (mcm1957) Text for E952 has been corrected [#446].
- (mcm1957) Adapt wording at W098 / E029 [#448].
- (mcm1957) Adapter-core 3.3.1 suggestion added [#455].
- (mcm1957) Admin 7.6.17 recommendation added [#435].
- (mcm1957) jsonConfig expertMode flag added [#386].

### 4.0.0 (2025-08-05)

- (mcm1957) use jsdelivr.com to retrive files from github.
- (mcm1957) Dependencies have been updated.

### 3.5.8 (2025-05-17)

- (mcm1957) add authorization for github using OWN_GITHUB_TOKEN.

### 3.5.5 (2025-04-28)

- (mcm1957) Node.js 20 is suggested now.
- (mcm1957) Suggested release for several packages has been encreased.
- (mcm1957) Do not raise E186 if E190 is raised anyway. [#387]
- (mcm1957) Dependencies have been updated.0

### 3.5.4 (2025-03-03)

- (mcm1957) Ignore boolean paramters when checking protectedNative/encryptedNative. [#395]

### 3.5.3 (2025-02-21)

- (mcm1957) Crash has been fixed if protectedNative/encryptedNative is not an array. [#385]

### 3.5.2 (2025-02-19)

- (mcm1957) Incorrect admin suggestion for very olf html adapters corrected. [#383]
- (mcm1957) Errors during parsing if icon improved. [#381]
- (mcm1957) Crash if protectedNative or encryptedNative is missing. [#382]

### 3.5.0 (2025-02-18)

- (mcm1957) Fixed dependency warning ([W174]) has been reduces to suggestion. [#374]
- (mcm1957) Some changes to jsonConfig check have been implemented.
- (mcm1957) common.supportCustoms check has been added. [#379]
- (mcm1957) Check that key listed at encryptedNative or protectedNative is listed at native too. [#218]
- (mcm1957) Check that key listed at encryptedNative is listed at protectedNative too. [#342]
- (mcm1957) Check that extension adapters require web adapter. [#311]
- (mcm1957) List of suspicious keys to protect has been extended. [#358]
- (mcm1957) checking of 'admin' globalDependency has been added.
- (mcm1957) checking of 'publishConfig.registry' has been added.
- (mcm1957) New commandline option --noinfo added.
- (mcm1957) Logging has been adapted.

### 3.4.4 (2025-02-12)

- (mcm1957) Some external attributes added to valid package.json attributes.

### 3.4.2 (2025-02-12)

- (mcm1957) 'type' and 'types' added to valid package.json attributes.

### 3.4.1 (2025-02-11)

- (mcm1957) Add 'publishConfig' to valid package.json attributes.

### 3.4.0 (2025-02-11)

- (mcm1957) Do not suggest to migrate to adapter-dev if only gulpfile.js exists. (#334).
- (mcm1957) Warn if onlyWWW adapter uses adapter-core (#251).
- (mcm1957) Singleton checks have been reduced to suggestion level.
- (mcm1957) Adapter-core 3.2. required now.
- (mcm1957) Blacklists for peerDependencies and optionalDependencies have been added (#364).
- (mcm1957) Suggestings for typical devDependencies have been added (#344).
- (mcm1957) Checking of package dependencies has been enhanced.
- (mcm1957) Allow legacy-testing instead of testing.
- (mcm1957) Warn if axios is listed as devDependency (#314).
- (mcm1957) Adapt common.materialize deprecation message (#315).
- (mcm1957) Log an error if dependency is listed multiple times (#316).
- (mcm1957) Check package.json for invalid attributes.
- (mcm1957) Fix duplicated warning E432 and E434.
- (mcm1957) Adapt copyright year advisory.

### 3.3.2 (2025-01-20)

- (mcm1957) Avoid crash if some file cannot be downloaded.

### 3.3.1 (2025-01-19)

- (mcm1957) Report malformed semver specifications has been fixed.

### 3.3.0 (2025-01-19)

- (mcm1957) "common.singleton" causes a warning now for non-onlyWWW Adapters.
- (mcm1957) "$schema" has been blacklisted at io-package.json.
- (mcm1957) Warn if 'common.nondeletable' flag is detected.
- (mcm1957) Report request as deprecated package.
- (mcm1957) Report malformed semver specifications.
- (mcm1957) Check of copyright-year complains about future dates now.
- (mcm1957) Checking for responsive design issues has been added.
- (mcm1957) Releaseinfo has been added to "checks" log.

### 3.2.4 (2025-01-16)

- (mcm1957) Suggested release of testing and adapter-core increased.

### 3.2.3 (2025-01-11)

- (mcm1957) An error is issued if js-controller dependency is missing.
- (mcm1957) Required js-controller has been increased to 5.0.19.
- (mcm1957) Recommended js-controller version is omitted if identical to required one.

### 3.2.2 (2024-11-01)

- (mcm1957) Link to open issues has been corrected.
- (mcm1957) Component name added to responsive check issues.

### 3.2.1 (2024-11-01)

- (mcm1957) Size checking for "divider" and "staticImage" suspended.

### 3.2.0 (2024-11-01)

- (oweitman) Script has been extended to use optionally local data for checking.
- (mcm1957) Warning if i18n is not used has been fixed [#324].
- (mcm1957) Check for importent issues has been added.
- (mcm1957) Checking of jsonConfig (initially) added.

### 3.1.4 (2024-10-26)

- (mcm1957) linter has been activated and issues reported have been fixed.
- (mcm1957) Blacklist for package/dependencies has been extended.
- (mcm1957) Recommend adapter-core 3.2.2 now.
- (mcm1957) Clearify test for "[E952] .npmignore not found". [#320]
- (mcm1957) Abort processing if iobroker.live not reachable. [#321]

### 3.1.3 (2024-10-11)

- (mcm1957) Checker no longer crash id no npm package exists.

### 3.1.2 (2024-10-04)

- (mcm1957) Require node 18 minimum as engines clause.

### 3.1.1 (2024-10-04)

- (mcm1957) "[E166] 'common.mode: extension' is unknown" has been fixed [#308]
- (mcm1957) "[E904] file iob_npm.done found in repository, but not found in .gitignore" removed as covered by [E503]. [#309]
- (mcm1957) "[E500] node_modules found" has been retricted to adapetr root. [#297]
- (mcm1957) Do not check main entry if common.mode none or extension.
- (mcm1957) Change "[W113] Adapter should support compact mode" text and honor common.compact set to false. [#300]

### 3.1.0 (2024-09-29)

- (mcm1957) "@iobroker/plugin-sentry" blacklisted as dependency [#301]
- (mcm1957) Accept .ts files as main file too. [#303]
- (mcm1957) [E405] and [E426] incorrect path has been corrected. [#299]

### 3.0.7 (2024-09-19)

- (mcm1957) "[W523] 'package-lock.json"'not found in repo!" reduced to suggestion. [#298]

### 3.0.6 (2024-09-13)

- (mcm1957) "[E124] Main file not found" no longer raised if `common.nogit` is set
- (mcm1957) 'Text of "common.main" is deprecated' has been adapted. [#266]
- (mcm1957) Ignore errors caused by complex .gitignor/.npmignore. [#288]

### 3.0.5 (2024-09-13)

- (mcm1957) '@iobroker/dev-server' is valid as dev-dependency. [#260]

### 3.0.4 (2024-09-12)

- (mcm1957) Abort with incorrect dependency definition fixed [#287]
- (mcm1957) Improve handling of malformed dependency definitions [#284]
- (mcm1957) Improve handling of malformed .releaseconfig.json files [#283]
- (mcm1957) Missing mandatory translations are considered an error now. [#277, #278]
- (mcm1957) '.npmignore found but "files" is used' is a warning now. [#274]
- (mcm1957) '@iobroker/dev-server' has been blacklisted as any dependency. [#260]
- (mcm1957) Do no longer require a js-controller dependency for wwwOnly adapters. [#250]

### 3.0.3 (2024-09-12)

- (mcm1957) Check for iob_npm.done at `.npmignore` has been removed [#294]

### 3.0.2 (2024-09-11)

- (mcm1957) Handling of a missing LICENSE file corrected. [#282]
- (mcm1957) [W126] Missing mandatory translation is an error now. [#293]
- (mcm1957) Record repochcker version used for tests.
- (mcm1957) Record GitHub commit-sha of last commit used for tests.

### 3.0.0 (2024-09-10)

- (mcm1957) Error and warning numbering has been reviewed and duplicates removed.
- (mcm1957) index.js has been split into seperated modules.

### 2.10.0 (2024-08-19)

- (mcm1957) Suggestions ([Sxxx] have been added).

### 2.9.1 (2024-08-12)

- (mcm1957) E162 - correct dependency check for js-controller. [#267].
- (mcm1957) E605 - copyright year range including whitespaces is now accepted. [#269].
- (mcm1957) E016 - missing vaiable expansion has been added. [#263].
- (mcm1957) E114 - typo at error message has been fixed [#261].

### 2.9.0 (2024-07-29)

- (mcm1957) Adapt text if sources-dist(-stable).json need a correction [#97].
- (mcm1957) Missing "common.mode" error text corrected [#249].
- (mcm1957) Files "iob" and "iobroker" are disallowed now [#248].
- (mcm1957) Checks related to @alcalzone/releasescript modified [#71].
- (mcm1957) Text of E114 (missing adminUI) adapted.

### 2.8.1 (2024-07-28)

- (mcm1957) Check of js-controller version has been corrected [#247].
- (mcm1957) Honor '>' at dependency checks too [#246].

### 2.8.0 (2024-07-28)

- (mcm1957) Copyright year check has been fixed for single year entries.
- (mcm1957) js-controller version check added [#233].
- (mcm1957) Check for fixed version dependencies and for github dependencies [#233].
- (mcm1957) Missing language files reduced to warning [#203].
- (mcm1957) Missing .gitignore is considered an error now.
- (mcm1957) "common.noConfig" no longer reported as error if "common.adminUI" is present [#245].
- (mcm1957) "common.noConfig" must match "common.adminUI" setting [#170].

### 2.7.2 (2024-07-26)

- (mcm1957) package-lock.json check fixed.

### 2.7.1 (2024-07-26)

- (mcm1957) Reduce setTimeout/setInterval error to warning temporary.

### 2.7.0 (2024-07-26)

- (mcm1957) Some non trivial keywords related to adapter are enforced now [#234].
- (mcm1957) Severity if [E105] / [W105] has been corrected [#204].
- (mcm1957) Disallow 'globalDependencies' at package.json [#204].
- (mcm1957) Several false positives for wwwOnly widgetadapters have been fixed [#230, #222].
- (mcm1957) Missing .npmignore is now considered an error [#229].
- (mcm1957) Usage of package.json 'files' section is now recommended.
- (mcm1957) If more than 7 common.news entries are present a warning is issued now [#232].
- (mcm1957) Versions listed at common.news are checked to exist at npm now [#226].
- (mcm1957) 'package-lock.json' is checked to exist at GitHub now [#188].
- (mcm1957) travis checks have been removed [#237].
- (mcm1957) Copyright year now honors commit year and npm publish year too [#237].

### 2.6.1 (2024-06-24)

- (mcm1957) Check "[W156] Adapter should support admin 5 UI (jsonConfig)" checks for reactUi now.

### 2.6.0 (2024-06-24)

- (mcm1957) Check has been aded to ensure keywords and common.keywords are present. [#200]
- (mcm1957) Detection of react has been added, gulpfile.js is accepted for react based UIs now. [#223]

### 2.5.1 (2024-06-24)

- (mcm1957) Suggestion to update dependencies to recommended version added.
- (mcm1957) Adapter-core recommended set to 3.1.6 [#220]

### 2.5.0 (2024-05-30)

- (mcm1957) Check to ensure that dependency revisions are available at repository added. [#180]

### 2.4.0 (2024-05-30)

- (mcm1957) Add check to protect sensitive data. [#195]
- (mcm1957) Add check to verify that dependencies and globalDepencies are of type array. [#90]

### 2.3.1 (2024-05-07)

- (mcm1957) Reduce number of missing translation warnings.
- (mcm1957) Seperate between required and recommended translations.
- (mcm1957) Log missing translations in detail.

### 2.3.0 (2024-05-07)

- (mcm1957) Elements marked as deprectaed added to blacklist.
- (mcm1957) Blacklist added to block elements at package.json and io-package.json.
- (mcm1957) Error [E000] will be raised now if repository cannot be accessed at all [#194].
- (mcm1957) Reading of package.json and io-package.json has been moved to head of tests.
- (mcm1957) Check minimum and recommended node version at package.json (#160)
- (mcm1957) Raise an error if version at package.json is lower than latest release at npmjs [#192]

### 2.2.3 (2024-03-29)

- (mcm1957) Checking of license has been improved

### 2.2.2 (2024-03-29)

- (mcm1957) Checking of adapter-core has been fixed
- (mcm1957) Load all potential interesting files, fixes [#149]

### 2.2.1 (2024-03-26)

- (mcm1957) Added check that own adapter is not listed at common.restartAdapters
- (mcm1957) Added check of version strings at common.news
- (mcm1957) Added check for recommended node version (node 18 for now)
- (mcm1957) Disallow common.mode == subscribe
- (mcm1957) Deprecate common.wakeup
- (mcm1957) Added check for adapter-core version (>= 3.0.6)

### 2.2.0 (2024-03-24)

- (klein0r) Added check for licenseInformation
- (klein0r) Added check for deprecated license
- (klein0r) Added check for required attribute common.tier
- (klein0r) Added check for disallowed attribute common.automaticUpgrade

### 2.1.13 (2024-01-02)

- (bluefox) Corrected rule W156: adminUI.config === 'none' is allowed

### 2.1.12 (2023-09-21)

- (bluefox) Added check of using '\_' in adapter name

### 2.1.11 (2023-09-05)

- (bluefox) Added check of iobroker.js-controller in dependencies

### 2.1.7 (2023-08-14)

- (mcm57) Update index.js - fix typo in error message (packet.json)
- (mcm57) Update index.js - renumber E504/1 to 519 - fixes #112

### 2.1.6 (2022-12-08)

- (bluefox) added better error logging

### 2.1.5 (2022-12-07)

- (bluefox) added check of `.releaseconfig.json` file

### 2.1.4 (2022-08-19)

- (bluefox) Added check for adapter name: it may not start with '\_'

### 2.1.2 (2022-07-14)

- (bluefox) Fixed some errors

### 2.1.0 (2022-05-26)

- (bluefox) Added support for jsonConfig.json5 and jsonCustom.json5

### 2.0.5 (2022-05-22)

- (bluefox) Made it possible to run with npx

## License

The MIT License (MIT)

Copyright (c) 2014-2025 Denis Haev <dogafox@gmail.com>

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN

THE SOFTWARE.
